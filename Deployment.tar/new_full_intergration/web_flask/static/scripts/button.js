document.getElementById('all').addEventListener('click', function() {
    alert('Success');
});